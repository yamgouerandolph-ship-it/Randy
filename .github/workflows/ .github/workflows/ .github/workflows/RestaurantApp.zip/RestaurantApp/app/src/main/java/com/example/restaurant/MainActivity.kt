@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.restaurant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ------------------------------------------------------------
// A MODIFIER : infos du restaurant, offres et menu
// ------------------------------------------------------------
object Config {
    const val NOM = "Chez Mama Africa"
    const val SLOGAN = "Cuisine camerounaise"
    // Numéro au format international, sans "+" ni espaces
    const val TELEPHONE = "237600000000"
}

data class Plat(val nom: String, val prix: Int, val categorie: String)

val menu = listOf(
    Plat("Poulet DG", 4500, "Plats"),
    Plat("Ndolé et plantain", 3500, "Plats"),
    Plat("Poisson braisé", 4000, "Plats"),
    Plat("Jus de gingembre", 1000, "Boissons"),
    Plat("Jus de bissap", 1000, "Boissons"),
    Plat("Salade de fruits", 1500, "Desserts"),
    Plat("Gâteau maison", 1500, "Desserts"),
)

data class Offre(val titre: String, val details: String)

val offres = listOf(
    Offre("Menu midi à 3 000 FCFA", "Plat, boisson et dessert. Du lundi au vendredi, de 12 h à 15 h."),
    Offre("Jus offert le vendredi", "Pour tout plat commandé sur place."),
    Offre("Livraison gratuite", "Dès 10 000 FCFA, dans le centre-ville."),
)
// ------------------------------------------------------------

fun fcfa(n: Int): String = "%,d".format(n).replace(',', ' ') + " FCFA"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme { App() }
        }
    }
}

@Composable
fun App() {
    var onglet by remember { mutableIntStateOf(0) }
    val panier = remember { mutableStateMapOf<Int, Int>() }
    val quantite = panier.values.sum()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(Config.NOM, fontWeight = FontWeight.Medium)
                        Text(Config.SLOGAN, fontSize = 12.sp)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = onglet == 0, onClick = { onglet = 0 },
                    icon = { Icon(Icons.Default.Star, contentDescription = null) },
                    label = { Text("Offres") }
                )
                NavigationBarItem(
                    selected = onglet == 1, onClick = { onglet = 1 },
                    icon = { Icon(Icons.Default.Menu, contentDescription = null) },
                    label = { Text("Menu") }
                )
                NavigationBarItem(
                    selected = onglet == 2, onClick = { onglet = 2 },
                    icon = { Icon(Icons.Default.ShoppingCart, contentDescription = null) },
                    label = { Text(if (quantite > 0) "Commande ($quantite)" else "Commande") }
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (onglet) {
                0 -> OffresScreen(onVoirMenu = { onglet = 1 })
                1 -> MenuScreen(panier)
                else -> CommandeScreen(panier, onVoirMenu = { onglet = 1 })
            }
        }
    }
}

@Composable
fun OffresScreen(onVoirMenu: () -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(offres.withIndex().toList()) { (i, offre) ->
            val premiere = i == 0
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (premiere) MaterialTheme.colorScheme.tertiaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(Modifier.padding(16.dp)) {
                    if (premiere) {
                        Text("OFFRE DU JOUR", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(4.dp))
                    }
                    Text(offre.titre, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(4.dp))
                    Text(offre.details, fontSize = 14.sp)
                    if (premiere) {
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = onVoirMenu) { Text("Voir le menu") }
                    }
                }
            }
        }
    }
}

@Composable
fun MenuScreen(panier: MutableMap<Int, Int>) {
    val categories = listOf("Tous") + menu.map { it.categorie }.distinct()
    var choix by remember { mutableStateOf("Tous") }
    val affiches = menu.withIndex().filter { choix == "Tous" || it.value.categorie == choix }

    Column {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { c ->
                FilterChip(
                    selected = choix == c,
                    onClick = { choix = c },
                    label = { Text(c) }
                )
            }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp)) {
            items(affiches) { (index, plat) ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Pour une vraie photo : remplacer ce Box par Image(painterResource(R.drawable.xxx), ...)
                    Box(
                        Modifier
                            .size(56.dp)
                            .background(
                                MaterialTheme.colorScheme.tertiaryContainer,
                                RoundedCornerShape(8.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(plat.nom.take(1), fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(plat.nom, fontWeight = FontWeight.Medium)
                        Text(fcfa(plat.prix), fontSize = 13.sp)
                    }
                    OutlinedButton(onClick = { panier[index] = (panier[index] ?: 0) + 1 }) {
                        val n = panier[index] ?: 0
                        if (n > 0) Text("$n ")
                        Icon(Icons.Default.Add, contentDescription = "Ajouter ${plat.nom}")
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun CommandeScreen(panier: MutableMap<Int, Int>, onVoirMenu: () -> Unit) {
    val context = LocalContext.current
    val lignes = panier.entries.filter { it.value > 0 }.sortedBy { it.key }
    val total = lignes.sumOf { menu[it.key].prix * it.value }

    Column(Modifier.padding(16.dp)) {
        if (lignes.isEmpty()) {
            Text("Votre panier est vide", fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text("Ajoutez des plats depuis le menu pour les envoyer au restaurant.", fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onVoirMenu) { Text("Voir le menu") }
        } else {
            lignes.forEach { (index, n) ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("$n × ${menu[index].nom}", Modifier.weight(1f))
                    Text(fcfa(menu[index].prix * n), fontSize = 13.sp)
                    TextButton(onClick = {
                        if (n <= 1) panier.remove(index) else panier[index] = n - 1
                    }) { Text("−") }
                }
                HorizontalDivider()
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Total", fontWeight = FontWeight.Medium)
                Text(fcfa(total), fontWeight = FontWeight.Medium)
            }

            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val message = buildString {
                        append("Bonjour, je souhaite commander :\n")
                        lignes.forEach { (i, n) -> append("- $n × ${menu[i].nom}\n") }
                        append("Total : ${fcfa(total)}")
                    }
                    val uri = Uri.parse("https://wa.me/${Config.TELEPHONE}?text=${Uri.encode(message)}")
                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                }
            ) { Text("Commander sur WhatsApp") }

            Spacer(Modifier.height(8.dp))

            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:+${Config.TELEPHONE}")))
                }
            ) {
                Icon(Icons.Default.Phone, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Appeler pour réserver")
            }
        }
    }
}
